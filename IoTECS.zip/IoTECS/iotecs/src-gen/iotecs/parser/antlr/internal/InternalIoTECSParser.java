package iotecs.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import iotecs.services.IoTECSGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalIoTECSParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Platform:'", "'{'", "'type:'", "'networkAdapter:'", "'locationIP:'", "'userName:'", "'password:'", "'cpu:'", "'memory:'", "'G'", "'ipVM:'", "'userNameVM:'", "'passwordVM:'", "'}'", "'Simulator:'", "'duration:'", "'step:'", "'simulationNodes:'", "'Cloud:'", "'ip:'", "'port:'", "'usrname:'", "'workload:'", "'SimulationNode:'", "'platform:'", "'EdgeDevices:'", "'['", "']'", "','", "'EdgeDevice:'", "'protocol:'", "'speed:'", "'cloud:'", "'devices:'", "'Max'", "'Device:'", "'period:'", "'payload:'", "'.'", "'ms'", "'s'", "'m'", "'h'", "'b'", "'Mb'", "'Kb'", "'UDP'", "'TCP'", "'Docker'", "'VM'", "'Native'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalIoTECSParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalIoTECSParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalIoTECSParser.tokenNames; }
    public String getGrammarFileName() { return "InternalIoTECS.g"; }



     	private IoTECSGrammarAccess grammarAccess;

        public InternalIoTECSParser(TokenStream input, IoTECSGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected IoTECSGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalIoTECS.g:65:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalIoTECS.g:65:46: (iv_ruleModel= ruleModel EOF )
            // InternalIoTECS.g:66:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalIoTECS.g:72:1: ruleModel returns [EObject current=null] : ( (lv_elements_0_0= ruleElement ) )* ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_elements_0_0 = null;



        	enterRule();

        try {
            // InternalIoTECS.g:78:2: ( ( (lv_elements_0_0= ruleElement ) )* )
            // InternalIoTECS.g:79:2: ( (lv_elements_0_0= ruleElement ) )*
            {
            // InternalIoTECS.g:79:2: ( (lv_elements_0_0= ruleElement ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11||LA1_0==25||LA1_0==29||LA1_0==34||LA1_0==40||LA1_0==46) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalIoTECS.g:80:3: (lv_elements_0_0= ruleElement )
            	    {
            	    // InternalIoTECS.g:80:3: (lv_elements_0_0= ruleElement )
            	    // InternalIoTECS.g:81:4: lv_elements_0_0= ruleElement
            	    {

            	    				newCompositeNode(grammarAccess.getModelAccess().getElementsElementParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_elements_0_0=ruleElement();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getModelRule());
            	    				}
            	    				add(
            	    					current,
            	    					"elements",
            	    					lv_elements_0_0,
            	    					"iotecs.IoTECS.Element");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleElement"
    // InternalIoTECS.g:101:1: entryRuleElement returns [EObject current=null] : iv_ruleElement= ruleElement EOF ;
    public final EObject entryRuleElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElement = null;


        try {
            // InternalIoTECS.g:101:48: (iv_ruleElement= ruleElement EOF )
            // InternalIoTECS.g:102:2: iv_ruleElement= ruleElement EOF
            {
             newCompositeNode(grammarAccess.getElementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleElement=ruleElement();

            state._fsp--;

             current =iv_ruleElement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElement"


    // $ANTLR start "ruleElement"
    // InternalIoTECS.g:108:1: ruleElement returns [EObject current=null] : (this_Simulator_0= ruleSimulator | this_Platform_1= rulePlatform | this_SimulationNode_2= ruleSimulationNode | this_EdgeDevice_3= ruleEdgeDevice | this_Device_4= ruleDevice | this_Cloud_5= ruleCloud ) ;
    public final EObject ruleElement() throws RecognitionException {
        EObject current = null;

        EObject this_Simulator_0 = null;

        EObject this_Platform_1 = null;

        EObject this_SimulationNode_2 = null;

        EObject this_EdgeDevice_3 = null;

        EObject this_Device_4 = null;

        EObject this_Cloud_5 = null;



        	enterRule();

        try {
            // InternalIoTECS.g:114:2: ( (this_Simulator_0= ruleSimulator | this_Platform_1= rulePlatform | this_SimulationNode_2= ruleSimulationNode | this_EdgeDevice_3= ruleEdgeDevice | this_Device_4= ruleDevice | this_Cloud_5= ruleCloud ) )
            // InternalIoTECS.g:115:2: (this_Simulator_0= ruleSimulator | this_Platform_1= rulePlatform | this_SimulationNode_2= ruleSimulationNode | this_EdgeDevice_3= ruleEdgeDevice | this_Device_4= ruleDevice | this_Cloud_5= ruleCloud )
            {
            // InternalIoTECS.g:115:2: (this_Simulator_0= ruleSimulator | this_Platform_1= rulePlatform | this_SimulationNode_2= ruleSimulationNode | this_EdgeDevice_3= ruleEdgeDevice | this_Device_4= ruleDevice | this_Cloud_5= ruleCloud )
            int alt2=6;
            switch ( input.LA(1) ) {
            case 25:
                {
                alt2=1;
                }
                break;
            case 11:
                {
                alt2=2;
                }
                break;
            case 34:
                {
                alt2=3;
                }
                break;
            case 40:
                {
                alt2=4;
                }
                break;
            case 46:
                {
                alt2=5;
                }
                break;
            case 29:
                {
                alt2=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalIoTECS.g:116:3: this_Simulator_0= ruleSimulator
                    {

                    			newCompositeNode(grammarAccess.getElementAccess().getSimulatorParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Simulator_0=ruleSimulator();

                    state._fsp--;


                    			current = this_Simulator_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalIoTECS.g:125:3: this_Platform_1= rulePlatform
                    {

                    			newCompositeNode(grammarAccess.getElementAccess().getPlatformParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Platform_1=rulePlatform();

                    state._fsp--;


                    			current = this_Platform_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalIoTECS.g:134:3: this_SimulationNode_2= ruleSimulationNode
                    {

                    			newCompositeNode(grammarAccess.getElementAccess().getSimulationNodeParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_SimulationNode_2=ruleSimulationNode();

                    state._fsp--;


                    			current = this_SimulationNode_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalIoTECS.g:143:3: this_EdgeDevice_3= ruleEdgeDevice
                    {

                    			newCompositeNode(grammarAccess.getElementAccess().getEdgeDeviceParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_EdgeDevice_3=ruleEdgeDevice();

                    state._fsp--;


                    			current = this_EdgeDevice_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalIoTECS.g:152:3: this_Device_4= ruleDevice
                    {

                    			newCompositeNode(grammarAccess.getElementAccess().getDeviceParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_Device_4=ruleDevice();

                    state._fsp--;


                    			current = this_Device_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalIoTECS.g:161:3: this_Cloud_5= ruleCloud
                    {

                    			newCompositeNode(grammarAccess.getElementAccess().getCloudParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_Cloud_5=ruleCloud();

                    state._fsp--;


                    			current = this_Cloud_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElement"


    // $ANTLR start "entryRulePlatform"
    // InternalIoTECS.g:173:1: entryRulePlatform returns [EObject current=null] : iv_rulePlatform= rulePlatform EOF ;
    public final EObject entryRulePlatform() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePlatform = null;


        try {
            // InternalIoTECS.g:173:49: (iv_rulePlatform= rulePlatform EOF )
            // InternalIoTECS.g:174:2: iv_rulePlatform= rulePlatform EOF
            {
             newCompositeNode(grammarAccess.getPlatformRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePlatform=rulePlatform();

            state._fsp--;

             current =iv_rulePlatform; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePlatform"


    // $ANTLR start "rulePlatform"
    // InternalIoTECS.g:180:1: rulePlatform returns [EObject current=null] : (otherlv_0= 'Platform:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'type:' ( (lv_type_4_0= rulePlatformType ) ) otherlv_5= 'networkAdapter:' ( (lv_networkAdapter_6_0= RULE_STRING ) ) (otherlv_7= 'locationIP:' ( (lv_location_8_0= ruleIP ) ) otherlv_9= 'userName:' ( (lv_user_10_0= RULE_ID ) ) otherlv_11= 'password:' ( (lv_password_12_0= RULE_STRING ) ) )? (otherlv_13= 'cpu:' ( (lv_CPU_14_0= RULE_INT ) ) otherlv_15= 'memory:' ( (lv_memory_16_0= RULE_INT ) ) otherlv_17= 'G' )? (otherlv_18= 'ipVM:' ( (lv_ipVM_19_0= ruleIP ) ) otherlv_20= 'userNameVM:' ( (lv_userVM_21_0= RULE_ID ) ) otherlv_22= 'passwordVM:' ( (lv_passwordVM_23_0= RULE_STRING ) ) )? otherlv_24= '}' ) ;
    public final EObject rulePlatform() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token lv_networkAdapter_6_0=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token lv_user_10_0=null;
        Token otherlv_11=null;
        Token lv_password_12_0=null;
        Token otherlv_13=null;
        Token lv_CPU_14_0=null;
        Token otherlv_15=null;
        Token lv_memory_16_0=null;
        Token otherlv_17=null;
        Token otherlv_18=null;
        Token otherlv_20=null;
        Token lv_userVM_21_0=null;
        Token otherlv_22=null;
        Token lv_passwordVM_23_0=null;
        Token otherlv_24=null;
        Enumerator lv_type_4_0 = null;

        AntlrDatatypeRuleToken lv_location_8_0 = null;

        AntlrDatatypeRuleToken lv_ipVM_19_0 = null;



        	enterRule();

        try {
            // InternalIoTECS.g:186:2: ( (otherlv_0= 'Platform:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'type:' ( (lv_type_4_0= rulePlatformType ) ) otherlv_5= 'networkAdapter:' ( (lv_networkAdapter_6_0= RULE_STRING ) ) (otherlv_7= 'locationIP:' ( (lv_location_8_0= ruleIP ) ) otherlv_9= 'userName:' ( (lv_user_10_0= RULE_ID ) ) otherlv_11= 'password:' ( (lv_password_12_0= RULE_STRING ) ) )? (otherlv_13= 'cpu:' ( (lv_CPU_14_0= RULE_INT ) ) otherlv_15= 'memory:' ( (lv_memory_16_0= RULE_INT ) ) otherlv_17= 'G' )? (otherlv_18= 'ipVM:' ( (lv_ipVM_19_0= ruleIP ) ) otherlv_20= 'userNameVM:' ( (lv_userVM_21_0= RULE_ID ) ) otherlv_22= 'passwordVM:' ( (lv_passwordVM_23_0= RULE_STRING ) ) )? otherlv_24= '}' ) )
            // InternalIoTECS.g:187:2: (otherlv_0= 'Platform:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'type:' ( (lv_type_4_0= rulePlatformType ) ) otherlv_5= 'networkAdapter:' ( (lv_networkAdapter_6_0= RULE_STRING ) ) (otherlv_7= 'locationIP:' ( (lv_location_8_0= ruleIP ) ) otherlv_9= 'userName:' ( (lv_user_10_0= RULE_ID ) ) otherlv_11= 'password:' ( (lv_password_12_0= RULE_STRING ) ) )? (otherlv_13= 'cpu:' ( (lv_CPU_14_0= RULE_INT ) ) otherlv_15= 'memory:' ( (lv_memory_16_0= RULE_INT ) ) otherlv_17= 'G' )? (otherlv_18= 'ipVM:' ( (lv_ipVM_19_0= ruleIP ) ) otherlv_20= 'userNameVM:' ( (lv_userVM_21_0= RULE_ID ) ) otherlv_22= 'passwordVM:' ( (lv_passwordVM_23_0= RULE_STRING ) ) )? otherlv_24= '}' )
            {
            // InternalIoTECS.g:187:2: (otherlv_0= 'Platform:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'type:' ( (lv_type_4_0= rulePlatformType ) ) otherlv_5= 'networkAdapter:' ( (lv_networkAdapter_6_0= RULE_STRING ) ) (otherlv_7= 'locationIP:' ( (lv_location_8_0= ruleIP ) ) otherlv_9= 'userName:' ( (lv_user_10_0= RULE_ID ) ) otherlv_11= 'password:' ( (lv_password_12_0= RULE_STRING ) ) )? (otherlv_13= 'cpu:' ( (lv_CPU_14_0= RULE_INT ) ) otherlv_15= 'memory:' ( (lv_memory_16_0= RULE_INT ) ) otherlv_17= 'G' )? (otherlv_18= 'ipVM:' ( (lv_ipVM_19_0= ruleIP ) ) otherlv_20= 'userNameVM:' ( (lv_userVM_21_0= RULE_ID ) ) otherlv_22= 'passwordVM:' ( (lv_passwordVM_23_0= RULE_STRING ) ) )? otherlv_24= '}' )
            // InternalIoTECS.g:188:3: otherlv_0= 'Platform:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'type:' ( (lv_type_4_0= rulePlatformType ) ) otherlv_5= 'networkAdapter:' ( (lv_networkAdapter_6_0= RULE_STRING ) ) (otherlv_7= 'locationIP:' ( (lv_location_8_0= ruleIP ) ) otherlv_9= 'userName:' ( (lv_user_10_0= RULE_ID ) ) otherlv_11= 'password:' ( (lv_password_12_0= RULE_STRING ) ) )? (otherlv_13= 'cpu:' ( (lv_CPU_14_0= RULE_INT ) ) otherlv_15= 'memory:' ( (lv_memory_16_0= RULE_INT ) ) otherlv_17= 'G' )? (otherlv_18= 'ipVM:' ( (lv_ipVM_19_0= ruleIP ) ) otherlv_20= 'userNameVM:' ( (lv_userVM_21_0= RULE_ID ) ) otherlv_22= 'passwordVM:' ( (lv_passwordVM_23_0= RULE_STRING ) ) )? otherlv_24= '}'
            {
            otherlv_0=(Token)match(input,11,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getPlatformAccess().getPlatformKeyword_0());
            		
            // InternalIoTECS.g:192:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalIoTECS.g:193:4: (lv_name_1_0= RULE_ID )
            {
            // InternalIoTECS.g:193:4: (lv_name_1_0= RULE_ID )
            // InternalIoTECS.g:194:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getPlatformAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPlatformRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getPlatformAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,13,FOLLOW_7); 

            			newLeafNode(otherlv_3, grammarAccess.getPlatformAccess().getTypeKeyword_3());
            		
            // InternalIoTECS.g:218:3: ( (lv_type_4_0= rulePlatformType ) )
            // InternalIoTECS.g:219:4: (lv_type_4_0= rulePlatformType )
            {
            // InternalIoTECS.g:219:4: (lv_type_4_0= rulePlatformType )
            // InternalIoTECS.g:220:5: lv_type_4_0= rulePlatformType
            {

            					newCompositeNode(grammarAccess.getPlatformAccess().getTypePlatformTypeEnumRuleCall_4_0());
            				
            pushFollow(FOLLOW_8);
            lv_type_4_0=rulePlatformType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPlatformRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_4_0,
            						"iotecs.IoTECS.PlatformType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,14,FOLLOW_9); 

            			newLeafNode(otherlv_5, grammarAccess.getPlatformAccess().getNetworkAdapterKeyword_5());
            		
            // InternalIoTECS.g:241:3: ( (lv_networkAdapter_6_0= RULE_STRING ) )
            // InternalIoTECS.g:242:4: (lv_networkAdapter_6_0= RULE_STRING )
            {
            // InternalIoTECS.g:242:4: (lv_networkAdapter_6_0= RULE_STRING )
            // InternalIoTECS.g:243:5: lv_networkAdapter_6_0= RULE_STRING
            {
            lv_networkAdapter_6_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_networkAdapter_6_0, grammarAccess.getPlatformAccess().getNetworkAdapterSTRINGTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPlatformRule());
            					}
            					setWithLastConsumed(
            						current,
            						"networkAdapter",
            						lv_networkAdapter_6_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalIoTECS.g:259:3: (otherlv_7= 'locationIP:' ( (lv_location_8_0= ruleIP ) ) otherlv_9= 'userName:' ( (lv_user_10_0= RULE_ID ) ) otherlv_11= 'password:' ( (lv_password_12_0= RULE_STRING ) ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==15) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalIoTECS.g:260:4: otherlv_7= 'locationIP:' ( (lv_location_8_0= ruleIP ) ) otherlv_9= 'userName:' ( (lv_user_10_0= RULE_ID ) ) otherlv_11= 'password:' ( (lv_password_12_0= RULE_STRING ) )
                    {
                    otherlv_7=(Token)match(input,15,FOLLOW_11); 

                    				newLeafNode(otherlv_7, grammarAccess.getPlatformAccess().getLocationIPKeyword_7_0());
                    			
                    // InternalIoTECS.g:264:4: ( (lv_location_8_0= ruleIP ) )
                    // InternalIoTECS.g:265:5: (lv_location_8_0= ruleIP )
                    {
                    // InternalIoTECS.g:265:5: (lv_location_8_0= ruleIP )
                    // InternalIoTECS.g:266:6: lv_location_8_0= ruleIP
                    {

                    						newCompositeNode(grammarAccess.getPlatformAccess().getLocationIPParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_location_8_0=ruleIP();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPlatformRule());
                    						}
                    						set(
                    							current,
                    							"location",
                    							lv_location_8_0,
                    							"iotecs.IoTECS.IP");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    otherlv_9=(Token)match(input,16,FOLLOW_4); 

                    				newLeafNode(otherlv_9, grammarAccess.getPlatformAccess().getUserNameKeyword_7_2());
                    			
                    // InternalIoTECS.g:287:4: ( (lv_user_10_0= RULE_ID ) )
                    // InternalIoTECS.g:288:5: (lv_user_10_0= RULE_ID )
                    {
                    // InternalIoTECS.g:288:5: (lv_user_10_0= RULE_ID )
                    // InternalIoTECS.g:289:6: lv_user_10_0= RULE_ID
                    {
                    lv_user_10_0=(Token)match(input,RULE_ID,FOLLOW_13); 

                    						newLeafNode(lv_user_10_0, grammarAccess.getPlatformAccess().getUserIDTerminalRuleCall_7_3_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPlatformRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"user",
                    							lv_user_10_0,
                    							"org.eclipse.xtext.common.Terminals.ID");
                    					

                    }


                    }

                    otherlv_11=(Token)match(input,17,FOLLOW_9); 

                    				newLeafNode(otherlv_11, grammarAccess.getPlatformAccess().getPasswordKeyword_7_4());
                    			
                    // InternalIoTECS.g:309:4: ( (lv_password_12_0= RULE_STRING ) )
                    // InternalIoTECS.g:310:5: (lv_password_12_0= RULE_STRING )
                    {
                    // InternalIoTECS.g:310:5: (lv_password_12_0= RULE_STRING )
                    // InternalIoTECS.g:311:6: lv_password_12_0= RULE_STRING
                    {
                    lv_password_12_0=(Token)match(input,RULE_STRING,FOLLOW_14); 

                    						newLeafNode(lv_password_12_0, grammarAccess.getPlatformAccess().getPasswordSTRINGTerminalRuleCall_7_5_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPlatformRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"password",
                    							lv_password_12_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalIoTECS.g:328:3: (otherlv_13= 'cpu:' ( (lv_CPU_14_0= RULE_INT ) ) otherlv_15= 'memory:' ( (lv_memory_16_0= RULE_INT ) ) otherlv_17= 'G' )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==18) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalIoTECS.g:329:4: otherlv_13= 'cpu:' ( (lv_CPU_14_0= RULE_INT ) ) otherlv_15= 'memory:' ( (lv_memory_16_0= RULE_INT ) ) otherlv_17= 'G'
                    {
                    otherlv_13=(Token)match(input,18,FOLLOW_11); 

                    				newLeafNode(otherlv_13, grammarAccess.getPlatformAccess().getCpuKeyword_8_0());
                    			
                    // InternalIoTECS.g:333:4: ( (lv_CPU_14_0= RULE_INT ) )
                    // InternalIoTECS.g:334:5: (lv_CPU_14_0= RULE_INT )
                    {
                    // InternalIoTECS.g:334:5: (lv_CPU_14_0= RULE_INT )
                    // InternalIoTECS.g:335:6: lv_CPU_14_0= RULE_INT
                    {
                    lv_CPU_14_0=(Token)match(input,RULE_INT,FOLLOW_15); 

                    						newLeafNode(lv_CPU_14_0, grammarAccess.getPlatformAccess().getCPUINTTerminalRuleCall_8_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPlatformRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"CPU",
                    							lv_CPU_14_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    otherlv_15=(Token)match(input,19,FOLLOW_11); 

                    				newLeafNode(otherlv_15, grammarAccess.getPlatformAccess().getMemoryKeyword_8_2());
                    			
                    // InternalIoTECS.g:355:4: ( (lv_memory_16_0= RULE_INT ) )
                    // InternalIoTECS.g:356:5: (lv_memory_16_0= RULE_INT )
                    {
                    // InternalIoTECS.g:356:5: (lv_memory_16_0= RULE_INT )
                    // InternalIoTECS.g:357:6: lv_memory_16_0= RULE_INT
                    {
                    lv_memory_16_0=(Token)match(input,RULE_INT,FOLLOW_16); 

                    						newLeafNode(lv_memory_16_0, grammarAccess.getPlatformAccess().getMemoryINTTerminalRuleCall_8_3_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPlatformRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"memory",
                    							lv_memory_16_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    otherlv_17=(Token)match(input,20,FOLLOW_17); 

                    				newLeafNode(otherlv_17, grammarAccess.getPlatformAccess().getGKeyword_8_4());
                    			

                    }
                    break;

            }

            // InternalIoTECS.g:378:3: (otherlv_18= 'ipVM:' ( (lv_ipVM_19_0= ruleIP ) ) otherlv_20= 'userNameVM:' ( (lv_userVM_21_0= RULE_ID ) ) otherlv_22= 'passwordVM:' ( (lv_passwordVM_23_0= RULE_STRING ) ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==21) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalIoTECS.g:379:4: otherlv_18= 'ipVM:' ( (lv_ipVM_19_0= ruleIP ) ) otherlv_20= 'userNameVM:' ( (lv_userVM_21_0= RULE_ID ) ) otherlv_22= 'passwordVM:' ( (lv_passwordVM_23_0= RULE_STRING ) )
                    {
                    otherlv_18=(Token)match(input,21,FOLLOW_11); 

                    				newLeafNode(otherlv_18, grammarAccess.getPlatformAccess().getIpVMKeyword_9_0());
                    			
                    // InternalIoTECS.g:383:4: ( (lv_ipVM_19_0= ruleIP ) )
                    // InternalIoTECS.g:384:5: (lv_ipVM_19_0= ruleIP )
                    {
                    // InternalIoTECS.g:384:5: (lv_ipVM_19_0= ruleIP )
                    // InternalIoTECS.g:385:6: lv_ipVM_19_0= ruleIP
                    {

                    						newCompositeNode(grammarAccess.getPlatformAccess().getIpVMIPParserRuleCall_9_1_0());
                    					
                    pushFollow(FOLLOW_18);
                    lv_ipVM_19_0=ruleIP();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPlatformRule());
                    						}
                    						set(
                    							current,
                    							"ipVM",
                    							lv_ipVM_19_0,
                    							"iotecs.IoTECS.IP");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    otherlv_20=(Token)match(input,22,FOLLOW_4); 

                    				newLeafNode(otherlv_20, grammarAccess.getPlatformAccess().getUserNameVMKeyword_9_2());
                    			
                    // InternalIoTECS.g:406:4: ( (lv_userVM_21_0= RULE_ID ) )
                    // InternalIoTECS.g:407:5: (lv_userVM_21_0= RULE_ID )
                    {
                    // InternalIoTECS.g:407:5: (lv_userVM_21_0= RULE_ID )
                    // InternalIoTECS.g:408:6: lv_userVM_21_0= RULE_ID
                    {
                    lv_userVM_21_0=(Token)match(input,RULE_ID,FOLLOW_19); 

                    						newLeafNode(lv_userVM_21_0, grammarAccess.getPlatformAccess().getUserVMIDTerminalRuleCall_9_3_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPlatformRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"userVM",
                    							lv_userVM_21_0,
                    							"org.eclipse.xtext.common.Terminals.ID");
                    					

                    }


                    }

                    otherlv_22=(Token)match(input,23,FOLLOW_9); 

                    				newLeafNode(otherlv_22, grammarAccess.getPlatformAccess().getPasswordVMKeyword_9_4());
                    			
                    // InternalIoTECS.g:428:4: ( (lv_passwordVM_23_0= RULE_STRING ) )
                    // InternalIoTECS.g:429:5: (lv_passwordVM_23_0= RULE_STRING )
                    {
                    // InternalIoTECS.g:429:5: (lv_passwordVM_23_0= RULE_STRING )
                    // InternalIoTECS.g:430:6: lv_passwordVM_23_0= RULE_STRING
                    {
                    lv_passwordVM_23_0=(Token)match(input,RULE_STRING,FOLLOW_20); 

                    						newLeafNode(lv_passwordVM_23_0, grammarAccess.getPlatformAccess().getPasswordVMSTRINGTerminalRuleCall_9_5_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPlatformRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"passwordVM",
                    							lv_passwordVM_23_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_24=(Token)match(input,24,FOLLOW_2); 

            			newLeafNode(otherlv_24, grammarAccess.getPlatformAccess().getRightCurlyBracketKeyword_10());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePlatform"


    // $ANTLR start "entryRuleSimulator"
    // InternalIoTECS.g:455:1: entryRuleSimulator returns [EObject current=null] : iv_ruleSimulator= ruleSimulator EOF ;
    public final EObject entryRuleSimulator() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSimulator = null;


        try {
            // InternalIoTECS.g:455:50: (iv_ruleSimulator= ruleSimulator EOF )
            // InternalIoTECS.g:456:2: iv_ruleSimulator= ruleSimulator EOF
            {
             newCompositeNode(grammarAccess.getSimulatorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSimulator=ruleSimulator();

            state._fsp--;

             current =iv_ruleSimulator; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSimulator"


    // $ANTLR start "ruleSimulator"
    // InternalIoTECS.g:462:1: ruleSimulator returns [EObject current=null] : (otherlv_0= 'Simulator:' otherlv_1= '{' otherlv_2= 'duration:' ( (lv_duration_3_0= RULE_INT ) ) ( (lv_durationUnit_4_0= ruleTimeUnit ) ) otherlv_5= 'step:' ( (lv_step_6_0= RULE_INT ) ) ( (lv_stepUnit_7_0= ruleTimeUnit ) ) otherlv_8= 'simulationNodes:' otherlv_9= '{' ( (lv_simulationNodes_10_0= ruleSimulationNodes ) )* otherlv_11= '}' otherlv_12= '}' ) ;
    public final EObject ruleSimulator() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_duration_3_0=null;
        Token otherlv_5=null;
        Token lv_step_6_0=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Enumerator lv_durationUnit_4_0 = null;

        Enumerator lv_stepUnit_7_0 = null;

        EObject lv_simulationNodes_10_0 = null;



        	enterRule();

        try {
            // InternalIoTECS.g:468:2: ( (otherlv_0= 'Simulator:' otherlv_1= '{' otherlv_2= 'duration:' ( (lv_duration_3_0= RULE_INT ) ) ( (lv_durationUnit_4_0= ruleTimeUnit ) ) otherlv_5= 'step:' ( (lv_step_6_0= RULE_INT ) ) ( (lv_stepUnit_7_0= ruleTimeUnit ) ) otherlv_8= 'simulationNodes:' otherlv_9= '{' ( (lv_simulationNodes_10_0= ruleSimulationNodes ) )* otherlv_11= '}' otherlv_12= '}' ) )
            // InternalIoTECS.g:469:2: (otherlv_0= 'Simulator:' otherlv_1= '{' otherlv_2= 'duration:' ( (lv_duration_3_0= RULE_INT ) ) ( (lv_durationUnit_4_0= ruleTimeUnit ) ) otherlv_5= 'step:' ( (lv_step_6_0= RULE_INT ) ) ( (lv_stepUnit_7_0= ruleTimeUnit ) ) otherlv_8= 'simulationNodes:' otherlv_9= '{' ( (lv_simulationNodes_10_0= ruleSimulationNodes ) )* otherlv_11= '}' otherlv_12= '}' )
            {
            // InternalIoTECS.g:469:2: (otherlv_0= 'Simulator:' otherlv_1= '{' otherlv_2= 'duration:' ( (lv_duration_3_0= RULE_INT ) ) ( (lv_durationUnit_4_0= ruleTimeUnit ) ) otherlv_5= 'step:' ( (lv_step_6_0= RULE_INT ) ) ( (lv_stepUnit_7_0= ruleTimeUnit ) ) otherlv_8= 'simulationNodes:' otherlv_9= '{' ( (lv_simulationNodes_10_0= ruleSimulationNodes ) )* otherlv_11= '}' otherlv_12= '}' )
            // InternalIoTECS.g:470:3: otherlv_0= 'Simulator:' otherlv_1= '{' otherlv_2= 'duration:' ( (lv_duration_3_0= RULE_INT ) ) ( (lv_durationUnit_4_0= ruleTimeUnit ) ) otherlv_5= 'step:' ( (lv_step_6_0= RULE_INT ) ) ( (lv_stepUnit_7_0= ruleTimeUnit ) ) otherlv_8= 'simulationNodes:' otherlv_9= '{' ( (lv_simulationNodes_10_0= ruleSimulationNodes ) )* otherlv_11= '}' otherlv_12= '}'
            {
            otherlv_0=(Token)match(input,25,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getSimulatorAccess().getSimulatorKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_21); 

            			newLeafNode(otherlv_1, grammarAccess.getSimulatorAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,26,FOLLOW_11); 

            			newLeafNode(otherlv_2, grammarAccess.getSimulatorAccess().getDurationKeyword_2());
            		
            // InternalIoTECS.g:482:3: ( (lv_duration_3_0= RULE_INT ) )
            // InternalIoTECS.g:483:4: (lv_duration_3_0= RULE_INT )
            {
            // InternalIoTECS.g:483:4: (lv_duration_3_0= RULE_INT )
            // InternalIoTECS.g:484:5: lv_duration_3_0= RULE_INT
            {
            lv_duration_3_0=(Token)match(input,RULE_INT,FOLLOW_22); 

            					newLeafNode(lv_duration_3_0, grammarAccess.getSimulatorAccess().getDurationINTTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSimulatorRule());
            					}
            					setWithLastConsumed(
            						current,
            						"duration",
            						lv_duration_3_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalIoTECS.g:500:3: ( (lv_durationUnit_4_0= ruleTimeUnit ) )
            // InternalIoTECS.g:501:4: (lv_durationUnit_4_0= ruleTimeUnit )
            {
            // InternalIoTECS.g:501:4: (lv_durationUnit_4_0= ruleTimeUnit )
            // InternalIoTECS.g:502:5: lv_durationUnit_4_0= ruleTimeUnit
            {

            					newCompositeNode(grammarAccess.getSimulatorAccess().getDurationUnitTimeUnitEnumRuleCall_4_0());
            				
            pushFollow(FOLLOW_23);
            lv_durationUnit_4_0=ruleTimeUnit();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSimulatorRule());
            					}
            					set(
            						current,
            						"durationUnit",
            						lv_durationUnit_4_0,
            						"iotecs.IoTECS.TimeUnit");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,27,FOLLOW_11); 

            			newLeafNode(otherlv_5, grammarAccess.getSimulatorAccess().getStepKeyword_5());
            		
            // InternalIoTECS.g:523:3: ( (lv_step_6_0= RULE_INT ) )
            // InternalIoTECS.g:524:4: (lv_step_6_0= RULE_INT )
            {
            // InternalIoTECS.g:524:4: (lv_step_6_0= RULE_INT )
            // InternalIoTECS.g:525:5: lv_step_6_0= RULE_INT
            {
            lv_step_6_0=(Token)match(input,RULE_INT,FOLLOW_22); 

            					newLeafNode(lv_step_6_0, grammarAccess.getSimulatorAccess().getStepINTTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSimulatorRule());
            					}
            					setWithLastConsumed(
            						current,
            						"step",
            						lv_step_6_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalIoTECS.g:541:3: ( (lv_stepUnit_7_0= ruleTimeUnit ) )
            // InternalIoTECS.g:542:4: (lv_stepUnit_7_0= ruleTimeUnit )
            {
            // InternalIoTECS.g:542:4: (lv_stepUnit_7_0= ruleTimeUnit )
            // InternalIoTECS.g:543:5: lv_stepUnit_7_0= ruleTimeUnit
            {

            					newCompositeNode(grammarAccess.getSimulatorAccess().getStepUnitTimeUnitEnumRuleCall_7_0());
            				
            pushFollow(FOLLOW_24);
            lv_stepUnit_7_0=ruleTimeUnit();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSimulatorRule());
            					}
            					set(
            						current,
            						"stepUnit",
            						lv_stepUnit_7_0,
            						"iotecs.IoTECS.TimeUnit");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_8=(Token)match(input,28,FOLLOW_5); 

            			newLeafNode(otherlv_8, grammarAccess.getSimulatorAccess().getSimulationNodesKeyword_8());
            		
            otherlv_9=(Token)match(input,12,FOLLOW_25); 

            			newLeafNode(otherlv_9, grammarAccess.getSimulatorAccess().getLeftCurlyBracketKeyword_9());
            		
            // InternalIoTECS.g:568:3: ( (lv_simulationNodes_10_0= ruleSimulationNodes ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==RULE_ID) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalIoTECS.g:569:4: (lv_simulationNodes_10_0= ruleSimulationNodes )
            	    {
            	    // InternalIoTECS.g:569:4: (lv_simulationNodes_10_0= ruleSimulationNodes )
            	    // InternalIoTECS.g:570:5: lv_simulationNodes_10_0= ruleSimulationNodes
            	    {

            	    					newCompositeNode(grammarAccess.getSimulatorAccess().getSimulationNodesSimulationNodesParserRuleCall_10_0());
            	    				
            	    pushFollow(FOLLOW_25);
            	    lv_simulationNodes_10_0=ruleSimulationNodes();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSimulatorRule());
            	    					}
            	    					add(
            	    						current,
            	    						"simulationNodes",
            	    						lv_simulationNodes_10_0,
            	    						"iotecs.IoTECS.SimulationNodes");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            otherlv_11=(Token)match(input,24,FOLLOW_20); 

            			newLeafNode(otherlv_11, grammarAccess.getSimulatorAccess().getRightCurlyBracketKeyword_11());
            		
            otherlv_12=(Token)match(input,24,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getSimulatorAccess().getRightCurlyBracketKeyword_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSimulator"


    // $ANTLR start "entryRuleCloud"
    // InternalIoTECS.g:599:1: entryRuleCloud returns [EObject current=null] : iv_ruleCloud= ruleCloud EOF ;
    public final EObject entryRuleCloud() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCloud = null;


        try {
            // InternalIoTECS.g:599:46: (iv_ruleCloud= ruleCloud EOF )
            // InternalIoTECS.g:600:2: iv_ruleCloud= ruleCloud EOF
            {
             newCompositeNode(grammarAccess.getCloudRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCloud=ruleCloud();

            state._fsp--;

             current =iv_ruleCloud; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCloud"


    // $ANTLR start "ruleCloud"
    // InternalIoTECS.g:606:1: ruleCloud returns [EObject current=null] : (otherlv_0= 'Cloud:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'ip:' ( (lv_ip_4_0= ruleIP ) ) otherlv_5= 'port:' ( (lv_port_6_0= RULE_INT ) ) (otherlv_7= 'usrname:' ( (lv_usrname_8_0= RULE_STRING ) ) otherlv_9= 'password:' ( (lv_password_10_0= RULE_STRING ) ) otherlv_11= 'workload:' ( (lv_workload_12_0= RULE_INT ) ) ( (lv_workloadUnit_13_0= ruleTimeUnitForWorkload ) ) )? (otherlv_14= 'networkAdapter:' ( (lv_networkAdapter_15_0= RULE_STRING ) ) )? otherlv_16= '}' ) ;
    public final EObject ruleCloud() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token lv_port_6_0=null;
        Token otherlv_7=null;
        Token lv_usrname_8_0=null;
        Token otherlv_9=null;
        Token lv_password_10_0=null;
        Token otherlv_11=null;
        Token lv_workload_12_0=null;
        Token otherlv_14=null;
        Token lv_networkAdapter_15_0=null;
        Token otherlv_16=null;
        AntlrDatatypeRuleToken lv_ip_4_0 = null;

        Enumerator lv_workloadUnit_13_0 = null;



        	enterRule();

        try {
            // InternalIoTECS.g:612:2: ( (otherlv_0= 'Cloud:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'ip:' ( (lv_ip_4_0= ruleIP ) ) otherlv_5= 'port:' ( (lv_port_6_0= RULE_INT ) ) (otherlv_7= 'usrname:' ( (lv_usrname_8_0= RULE_STRING ) ) otherlv_9= 'password:' ( (lv_password_10_0= RULE_STRING ) ) otherlv_11= 'workload:' ( (lv_workload_12_0= RULE_INT ) ) ( (lv_workloadUnit_13_0= ruleTimeUnitForWorkload ) ) )? (otherlv_14= 'networkAdapter:' ( (lv_networkAdapter_15_0= RULE_STRING ) ) )? otherlv_16= '}' ) )
            // InternalIoTECS.g:613:2: (otherlv_0= 'Cloud:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'ip:' ( (lv_ip_4_0= ruleIP ) ) otherlv_5= 'port:' ( (lv_port_6_0= RULE_INT ) ) (otherlv_7= 'usrname:' ( (lv_usrname_8_0= RULE_STRING ) ) otherlv_9= 'password:' ( (lv_password_10_0= RULE_STRING ) ) otherlv_11= 'workload:' ( (lv_workload_12_0= RULE_INT ) ) ( (lv_workloadUnit_13_0= ruleTimeUnitForWorkload ) ) )? (otherlv_14= 'networkAdapter:' ( (lv_networkAdapter_15_0= RULE_STRING ) ) )? otherlv_16= '}' )
            {
            // InternalIoTECS.g:613:2: (otherlv_0= 'Cloud:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'ip:' ( (lv_ip_4_0= ruleIP ) ) otherlv_5= 'port:' ( (lv_port_6_0= RULE_INT ) ) (otherlv_7= 'usrname:' ( (lv_usrname_8_0= RULE_STRING ) ) otherlv_9= 'password:' ( (lv_password_10_0= RULE_STRING ) ) otherlv_11= 'workload:' ( (lv_workload_12_0= RULE_INT ) ) ( (lv_workloadUnit_13_0= ruleTimeUnitForWorkload ) ) )? (otherlv_14= 'networkAdapter:' ( (lv_networkAdapter_15_0= RULE_STRING ) ) )? otherlv_16= '}' )
            // InternalIoTECS.g:614:3: otherlv_0= 'Cloud:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'ip:' ( (lv_ip_4_0= ruleIP ) ) otherlv_5= 'port:' ( (lv_port_6_0= RULE_INT ) ) (otherlv_7= 'usrname:' ( (lv_usrname_8_0= RULE_STRING ) ) otherlv_9= 'password:' ( (lv_password_10_0= RULE_STRING ) ) otherlv_11= 'workload:' ( (lv_workload_12_0= RULE_INT ) ) ( (lv_workloadUnit_13_0= ruleTimeUnitForWorkload ) ) )? (otherlv_14= 'networkAdapter:' ( (lv_networkAdapter_15_0= RULE_STRING ) ) )? otherlv_16= '}'
            {
            otherlv_0=(Token)match(input,29,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCloudAccess().getCloudKeyword_0());
            		
            // InternalIoTECS.g:618:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalIoTECS.g:619:4: (lv_name_1_0= RULE_ID )
            {
            // InternalIoTECS.g:619:4: (lv_name_1_0= RULE_ID )
            // InternalIoTECS.g:620:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCloudAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCloudRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_26); 

            			newLeafNode(otherlv_2, grammarAccess.getCloudAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,30,FOLLOW_11); 

            			newLeafNode(otherlv_3, grammarAccess.getCloudAccess().getIpKeyword_3());
            		
            // InternalIoTECS.g:644:3: ( (lv_ip_4_0= ruleIP ) )
            // InternalIoTECS.g:645:4: (lv_ip_4_0= ruleIP )
            {
            // InternalIoTECS.g:645:4: (lv_ip_4_0= ruleIP )
            // InternalIoTECS.g:646:5: lv_ip_4_0= ruleIP
            {

            					newCompositeNode(grammarAccess.getCloudAccess().getIpIPParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_27);
            lv_ip_4_0=ruleIP();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCloudRule());
            					}
            					set(
            						current,
            						"ip",
            						lv_ip_4_0,
            						"iotecs.IoTECS.IP");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,31,FOLLOW_11); 

            			newLeafNode(otherlv_5, grammarAccess.getCloudAccess().getPortKeyword_5());
            		
            // InternalIoTECS.g:667:3: ( (lv_port_6_0= RULE_INT ) )
            // InternalIoTECS.g:668:4: (lv_port_6_0= RULE_INT )
            {
            // InternalIoTECS.g:668:4: (lv_port_6_0= RULE_INT )
            // InternalIoTECS.g:669:5: lv_port_6_0= RULE_INT
            {
            lv_port_6_0=(Token)match(input,RULE_INT,FOLLOW_28); 

            					newLeafNode(lv_port_6_0, grammarAccess.getCloudAccess().getPortINTTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCloudRule());
            					}
            					setWithLastConsumed(
            						current,
            						"port",
            						lv_port_6_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalIoTECS.g:685:3: (otherlv_7= 'usrname:' ( (lv_usrname_8_0= RULE_STRING ) ) otherlv_9= 'password:' ( (lv_password_10_0= RULE_STRING ) ) otherlv_11= 'workload:' ( (lv_workload_12_0= RULE_INT ) ) ( (lv_workloadUnit_13_0= ruleTimeUnitForWorkload ) ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==32) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalIoTECS.g:686:4: otherlv_7= 'usrname:' ( (lv_usrname_8_0= RULE_STRING ) ) otherlv_9= 'password:' ( (lv_password_10_0= RULE_STRING ) ) otherlv_11= 'workload:' ( (lv_workload_12_0= RULE_INT ) ) ( (lv_workloadUnit_13_0= ruleTimeUnitForWorkload ) )
                    {
                    otherlv_7=(Token)match(input,32,FOLLOW_9); 

                    				newLeafNode(otherlv_7, grammarAccess.getCloudAccess().getUsrnameKeyword_7_0());
                    			
                    // InternalIoTECS.g:690:4: ( (lv_usrname_8_0= RULE_STRING ) )
                    // InternalIoTECS.g:691:5: (lv_usrname_8_0= RULE_STRING )
                    {
                    // InternalIoTECS.g:691:5: (lv_usrname_8_0= RULE_STRING )
                    // InternalIoTECS.g:692:6: lv_usrname_8_0= RULE_STRING
                    {
                    lv_usrname_8_0=(Token)match(input,RULE_STRING,FOLLOW_13); 

                    						newLeafNode(lv_usrname_8_0, grammarAccess.getCloudAccess().getUsrnameSTRINGTerminalRuleCall_7_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCloudRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"usrname",
                    							lv_usrname_8_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }

                    otherlv_9=(Token)match(input,17,FOLLOW_9); 

                    				newLeafNode(otherlv_9, grammarAccess.getCloudAccess().getPasswordKeyword_7_2());
                    			
                    // InternalIoTECS.g:712:4: ( (lv_password_10_0= RULE_STRING ) )
                    // InternalIoTECS.g:713:5: (lv_password_10_0= RULE_STRING )
                    {
                    // InternalIoTECS.g:713:5: (lv_password_10_0= RULE_STRING )
                    // InternalIoTECS.g:714:6: lv_password_10_0= RULE_STRING
                    {
                    lv_password_10_0=(Token)match(input,RULE_STRING,FOLLOW_29); 

                    						newLeafNode(lv_password_10_0, grammarAccess.getCloudAccess().getPasswordSTRINGTerminalRuleCall_7_3_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCloudRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"password",
                    							lv_password_10_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }

                    otherlv_11=(Token)match(input,33,FOLLOW_11); 

                    				newLeafNode(otherlv_11, grammarAccess.getCloudAccess().getWorkloadKeyword_7_4());
                    			
                    // InternalIoTECS.g:734:4: ( (lv_workload_12_0= RULE_INT ) )
                    // InternalIoTECS.g:735:5: (lv_workload_12_0= RULE_INT )
                    {
                    // InternalIoTECS.g:735:5: (lv_workload_12_0= RULE_INT )
                    // InternalIoTECS.g:736:6: lv_workload_12_0= RULE_INT
                    {
                    lv_workload_12_0=(Token)match(input,RULE_INT,FOLLOW_30); 

                    						newLeafNode(lv_workload_12_0, grammarAccess.getCloudAccess().getWorkloadINTTerminalRuleCall_7_5_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCloudRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"workload",
                    							lv_workload_12_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    // InternalIoTECS.g:752:4: ( (lv_workloadUnit_13_0= ruleTimeUnitForWorkload ) )
                    // InternalIoTECS.g:753:5: (lv_workloadUnit_13_0= ruleTimeUnitForWorkload )
                    {
                    // InternalIoTECS.g:753:5: (lv_workloadUnit_13_0= ruleTimeUnitForWorkload )
                    // InternalIoTECS.g:754:6: lv_workloadUnit_13_0= ruleTimeUnitForWorkload
                    {

                    						newCompositeNode(grammarAccess.getCloudAccess().getWorkloadUnitTimeUnitForWorkloadEnumRuleCall_7_6_0());
                    					
                    pushFollow(FOLLOW_31);
                    lv_workloadUnit_13_0=ruleTimeUnitForWorkload();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCloudRule());
                    						}
                    						set(
                    							current,
                    							"workloadUnit",
                    							lv_workloadUnit_13_0,
                    							"iotecs.IoTECS.TimeUnitForWorkload");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalIoTECS.g:772:3: (otherlv_14= 'networkAdapter:' ( (lv_networkAdapter_15_0= RULE_STRING ) ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==14) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalIoTECS.g:773:4: otherlv_14= 'networkAdapter:' ( (lv_networkAdapter_15_0= RULE_STRING ) )
                    {
                    otherlv_14=(Token)match(input,14,FOLLOW_9); 

                    				newLeafNode(otherlv_14, grammarAccess.getCloudAccess().getNetworkAdapterKeyword_8_0());
                    			
                    // InternalIoTECS.g:777:4: ( (lv_networkAdapter_15_0= RULE_STRING ) )
                    // InternalIoTECS.g:778:5: (lv_networkAdapter_15_0= RULE_STRING )
                    {
                    // InternalIoTECS.g:778:5: (lv_networkAdapter_15_0= RULE_STRING )
                    // InternalIoTECS.g:779:6: lv_networkAdapter_15_0= RULE_STRING
                    {
                    lv_networkAdapter_15_0=(Token)match(input,RULE_STRING,FOLLOW_20); 

                    						newLeafNode(lv_networkAdapter_15_0, grammarAccess.getCloudAccess().getNetworkAdapterSTRINGTerminalRuleCall_8_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCloudRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"networkAdapter",
                    							lv_networkAdapter_15_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_16=(Token)match(input,24,FOLLOW_2); 

            			newLeafNode(otherlv_16, grammarAccess.getCloudAccess().getRightCurlyBracketKeyword_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCloud"


    // $ANTLR start "entryRuleSimulationNode"
    // InternalIoTECS.g:804:1: entryRuleSimulationNode returns [EObject current=null] : iv_ruleSimulationNode= ruleSimulationNode EOF ;
    public final EObject entryRuleSimulationNode() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSimulationNode = null;


        try {
            // InternalIoTECS.g:804:55: (iv_ruleSimulationNode= ruleSimulationNode EOF )
            // InternalIoTECS.g:805:2: iv_ruleSimulationNode= ruleSimulationNode EOF
            {
             newCompositeNode(grammarAccess.getSimulationNodeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSimulationNode=ruleSimulationNode();

            state._fsp--;

             current =iv_ruleSimulationNode; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSimulationNode"


    // $ANTLR start "ruleSimulationNode"
    // InternalIoTECS.g:811:1: ruleSimulationNode returns [EObject current=null] : (otherlv_0= 'SimulationNode:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'platform:' ( (otherlv_4= RULE_ID ) ) otherlv_5= 'EdgeDevices:' otherlv_6= '{' ( (lv_edgeDevices_7_0= ruleEdgeDevices ) )* otherlv_8= '}' otherlv_9= '}' ) ;
    public final EObject ruleSimulationNode() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        EObject lv_edgeDevices_7_0 = null;



        	enterRule();

        try {
            // InternalIoTECS.g:817:2: ( (otherlv_0= 'SimulationNode:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'platform:' ( (otherlv_4= RULE_ID ) ) otherlv_5= 'EdgeDevices:' otherlv_6= '{' ( (lv_edgeDevices_7_0= ruleEdgeDevices ) )* otherlv_8= '}' otherlv_9= '}' ) )
            // InternalIoTECS.g:818:2: (otherlv_0= 'SimulationNode:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'platform:' ( (otherlv_4= RULE_ID ) ) otherlv_5= 'EdgeDevices:' otherlv_6= '{' ( (lv_edgeDevices_7_0= ruleEdgeDevices ) )* otherlv_8= '}' otherlv_9= '}' )
            {
            // InternalIoTECS.g:818:2: (otherlv_0= 'SimulationNode:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'platform:' ( (otherlv_4= RULE_ID ) ) otherlv_5= 'EdgeDevices:' otherlv_6= '{' ( (lv_edgeDevices_7_0= ruleEdgeDevices ) )* otherlv_8= '}' otherlv_9= '}' )
            // InternalIoTECS.g:819:3: otherlv_0= 'SimulationNode:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'platform:' ( (otherlv_4= RULE_ID ) ) otherlv_5= 'EdgeDevices:' otherlv_6= '{' ( (lv_edgeDevices_7_0= ruleEdgeDevices ) )* otherlv_8= '}' otherlv_9= '}'
            {
            otherlv_0=(Token)match(input,34,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getSimulationNodeAccess().getSimulationNodeKeyword_0());
            		
            // InternalIoTECS.g:823:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalIoTECS.g:824:4: (lv_name_1_0= RULE_ID )
            {
            // InternalIoTECS.g:824:4: (lv_name_1_0= RULE_ID )
            // InternalIoTECS.g:825:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getSimulationNodeAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSimulationNodeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_32); 

            			newLeafNode(otherlv_2, grammarAccess.getSimulationNodeAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,35,FOLLOW_4); 

            			newLeafNode(otherlv_3, grammarAccess.getSimulationNodeAccess().getPlatformKeyword_3());
            		
            // InternalIoTECS.g:849:3: ( (otherlv_4= RULE_ID ) )
            // InternalIoTECS.g:850:4: (otherlv_4= RULE_ID )
            {
            // InternalIoTECS.g:850:4: (otherlv_4= RULE_ID )
            // InternalIoTECS.g:851:5: otherlv_4= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSimulationNodeRule());
            					}
            				
            otherlv_4=(Token)match(input,RULE_ID,FOLLOW_33); 

            					newLeafNode(otherlv_4, grammarAccess.getSimulationNodeAccess().getPlatformPlatformCrossReference_4_0());
            				

            }


            }

            otherlv_5=(Token)match(input,36,FOLLOW_5); 

            			newLeafNode(otherlv_5, grammarAccess.getSimulationNodeAccess().getEdgeDevicesKeyword_5());
            		
            otherlv_6=(Token)match(input,12,FOLLOW_25); 

            			newLeafNode(otherlv_6, grammarAccess.getSimulationNodeAccess().getLeftCurlyBracketKeyword_6());
            		
            // InternalIoTECS.g:870:3: ( (lv_edgeDevices_7_0= ruleEdgeDevices ) )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==RULE_ID) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalIoTECS.g:871:4: (lv_edgeDevices_7_0= ruleEdgeDevices )
            	    {
            	    // InternalIoTECS.g:871:4: (lv_edgeDevices_7_0= ruleEdgeDevices )
            	    // InternalIoTECS.g:872:5: lv_edgeDevices_7_0= ruleEdgeDevices
            	    {

            	    					newCompositeNode(grammarAccess.getSimulationNodeAccess().getEdgeDevicesEdgeDevicesParserRuleCall_7_0());
            	    				
            	    pushFollow(FOLLOW_25);
            	    lv_edgeDevices_7_0=ruleEdgeDevices();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSimulationNodeRule());
            	    					}
            	    					add(
            	    						current,
            	    						"edgeDevices",
            	    						lv_edgeDevices_7_0,
            	    						"iotecs.IoTECS.EdgeDevices");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

            otherlv_8=(Token)match(input,24,FOLLOW_20); 

            			newLeafNode(otherlv_8, grammarAccess.getSimulationNodeAccess().getRightCurlyBracketKeyword_8());
            		
            otherlv_9=(Token)match(input,24,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getSimulationNodeAccess().getRightCurlyBracketKeyword_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSimulationNode"


    // $ANTLR start "entryRuleSimulationNodes"
    // InternalIoTECS.g:901:1: entryRuleSimulationNodes returns [EObject current=null] : iv_ruleSimulationNodes= ruleSimulationNodes EOF ;
    public final EObject entryRuleSimulationNodes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSimulationNodes = null;


        try {
            // InternalIoTECS.g:901:56: (iv_ruleSimulationNodes= ruleSimulationNodes EOF )
            // InternalIoTECS.g:902:2: iv_ruleSimulationNodes= ruleSimulationNodes EOF
            {
             newCompositeNode(grammarAccess.getSimulationNodesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSimulationNodes=ruleSimulationNodes();

            state._fsp--;

             current =iv_ruleSimulationNodes; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSimulationNodes"


    // $ANTLR start "ruleSimulationNodes"
    // InternalIoTECS.g:908:1: ruleSimulationNodes returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )? ) ;
    public final EObject ruleSimulationNodes() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_n_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalIoTECS.g:914:2: ( ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )? ) )
            // InternalIoTECS.g:915:2: ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )? )
            {
            // InternalIoTECS.g:915:2: ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )? )
            // InternalIoTECS.g:916:3: ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )?
            {
            // InternalIoTECS.g:916:3: ( (otherlv_0= RULE_ID ) )
            // InternalIoTECS.g:917:4: (otherlv_0= RULE_ID )
            {
            // InternalIoTECS.g:917:4: (otherlv_0= RULE_ID )
            // InternalIoTECS.g:918:5: otherlv_0= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSimulationNodesRule());
            					}
            				
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_34); 

            					newLeafNode(otherlv_0, grammarAccess.getSimulationNodesAccess().getSnSimulationNodeCrossReference_0_0());
            				

            }


            }

            otherlv_1=(Token)match(input,37,FOLLOW_11); 

            			newLeafNode(otherlv_1, grammarAccess.getSimulationNodesAccess().getLeftSquareBracketKeyword_1());
            		
            // InternalIoTECS.g:933:3: ( (lv_n_2_0= RULE_INT ) )
            // InternalIoTECS.g:934:4: (lv_n_2_0= RULE_INT )
            {
            // InternalIoTECS.g:934:4: (lv_n_2_0= RULE_INT )
            // InternalIoTECS.g:935:5: lv_n_2_0= RULE_INT
            {
            lv_n_2_0=(Token)match(input,RULE_INT,FOLLOW_35); 

            					newLeafNode(lv_n_2_0, grammarAccess.getSimulationNodesAccess().getNINTTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSimulationNodesRule());
            					}
            					setWithLastConsumed(
            						current,
            						"n",
            						lv_n_2_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_3=(Token)match(input,38,FOLLOW_36); 

            			newLeafNode(otherlv_3, grammarAccess.getSimulationNodesAccess().getRightSquareBracketKeyword_3());
            		
            // InternalIoTECS.g:955:3: (otherlv_4= ',' )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==39) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalIoTECS.g:956:4: otherlv_4= ','
                    {
                    otherlv_4=(Token)match(input,39,FOLLOW_2); 

                    				newLeafNode(otherlv_4, grammarAccess.getSimulationNodesAccess().getCommaKeyword_4());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSimulationNodes"


    // $ANTLR start "entryRuleEdgeDevice"
    // InternalIoTECS.g:965:1: entryRuleEdgeDevice returns [EObject current=null] : iv_ruleEdgeDevice= ruleEdgeDevice EOF ;
    public final EObject entryRuleEdgeDevice() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEdgeDevice = null;


        try {
            // InternalIoTECS.g:965:51: (iv_ruleEdgeDevice= ruleEdgeDevice EOF )
            // InternalIoTECS.g:966:2: iv_ruleEdgeDevice= ruleEdgeDevice EOF
            {
             newCompositeNode(grammarAccess.getEdgeDeviceRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEdgeDevice=ruleEdgeDevice();

            state._fsp--;

             current =iv_ruleEdgeDevice; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEdgeDevice"


    // $ANTLR start "ruleEdgeDevice"
    // InternalIoTECS.g:972:1: ruleEdgeDevice returns [EObject current=null] : (otherlv_0= 'EdgeDevice:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'protocol:' ( (lv_protocol_4_0= ruleProtocol ) ) otherlv_5= 'speed:' ( (lv_speed_6_0= ruleSpeed ) ) otherlv_7= 'cloud:' ( (otherlv_8= RULE_ID ) ) otherlv_9= 'workload:' ( (lv_workload_10_0= RULE_INT ) ) ( (lv_workloadUnit_11_0= ruleTimeUnitForWorkload ) ) otherlv_12= 'devices:' otherlv_13= '{' ( (lv_devices_14_0= ruleDevices ) )* otherlv_15= '}' otherlv_16= '}' ) ;
    public final EObject ruleEdgeDevice() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token lv_workload_10_0=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Enumerator lv_protocol_4_0 = null;

        AntlrDatatypeRuleToken lv_speed_6_0 = null;

        Enumerator lv_workloadUnit_11_0 = null;

        EObject lv_devices_14_0 = null;



        	enterRule();

        try {
            // InternalIoTECS.g:978:2: ( (otherlv_0= 'EdgeDevice:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'protocol:' ( (lv_protocol_4_0= ruleProtocol ) ) otherlv_5= 'speed:' ( (lv_speed_6_0= ruleSpeed ) ) otherlv_7= 'cloud:' ( (otherlv_8= RULE_ID ) ) otherlv_9= 'workload:' ( (lv_workload_10_0= RULE_INT ) ) ( (lv_workloadUnit_11_0= ruleTimeUnitForWorkload ) ) otherlv_12= 'devices:' otherlv_13= '{' ( (lv_devices_14_0= ruleDevices ) )* otherlv_15= '}' otherlv_16= '}' ) )
            // InternalIoTECS.g:979:2: (otherlv_0= 'EdgeDevice:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'protocol:' ( (lv_protocol_4_0= ruleProtocol ) ) otherlv_5= 'speed:' ( (lv_speed_6_0= ruleSpeed ) ) otherlv_7= 'cloud:' ( (otherlv_8= RULE_ID ) ) otherlv_9= 'workload:' ( (lv_workload_10_0= RULE_INT ) ) ( (lv_workloadUnit_11_0= ruleTimeUnitForWorkload ) ) otherlv_12= 'devices:' otherlv_13= '{' ( (lv_devices_14_0= ruleDevices ) )* otherlv_15= '}' otherlv_16= '}' )
            {
            // InternalIoTECS.g:979:2: (otherlv_0= 'EdgeDevice:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'protocol:' ( (lv_protocol_4_0= ruleProtocol ) ) otherlv_5= 'speed:' ( (lv_speed_6_0= ruleSpeed ) ) otherlv_7= 'cloud:' ( (otherlv_8= RULE_ID ) ) otherlv_9= 'workload:' ( (lv_workload_10_0= RULE_INT ) ) ( (lv_workloadUnit_11_0= ruleTimeUnitForWorkload ) ) otherlv_12= 'devices:' otherlv_13= '{' ( (lv_devices_14_0= ruleDevices ) )* otherlv_15= '}' otherlv_16= '}' )
            // InternalIoTECS.g:980:3: otherlv_0= 'EdgeDevice:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'protocol:' ( (lv_protocol_4_0= ruleProtocol ) ) otherlv_5= 'speed:' ( (lv_speed_6_0= ruleSpeed ) ) otherlv_7= 'cloud:' ( (otherlv_8= RULE_ID ) ) otherlv_9= 'workload:' ( (lv_workload_10_0= RULE_INT ) ) ( (lv_workloadUnit_11_0= ruleTimeUnitForWorkload ) ) otherlv_12= 'devices:' otherlv_13= '{' ( (lv_devices_14_0= ruleDevices ) )* otherlv_15= '}' otherlv_16= '}'
            {
            otherlv_0=(Token)match(input,40,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getEdgeDeviceAccess().getEdgeDeviceKeyword_0());
            		
            // InternalIoTECS.g:984:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalIoTECS.g:985:4: (lv_name_1_0= RULE_ID )
            {
            // InternalIoTECS.g:985:4: (lv_name_1_0= RULE_ID )
            // InternalIoTECS.g:986:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getEdgeDeviceAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEdgeDeviceRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_37); 

            			newLeafNode(otherlv_2, grammarAccess.getEdgeDeviceAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,41,FOLLOW_38); 

            			newLeafNode(otherlv_3, grammarAccess.getEdgeDeviceAccess().getProtocolKeyword_3());
            		
            // InternalIoTECS.g:1010:3: ( (lv_protocol_4_0= ruleProtocol ) )
            // InternalIoTECS.g:1011:4: (lv_protocol_4_0= ruleProtocol )
            {
            // InternalIoTECS.g:1011:4: (lv_protocol_4_0= ruleProtocol )
            // InternalIoTECS.g:1012:5: lv_protocol_4_0= ruleProtocol
            {

            					newCompositeNode(grammarAccess.getEdgeDeviceAccess().getProtocolProtocolEnumRuleCall_4_0());
            				
            pushFollow(FOLLOW_39);
            lv_protocol_4_0=ruleProtocol();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getEdgeDeviceRule());
            					}
            					set(
            						current,
            						"protocol",
            						lv_protocol_4_0,
            						"iotecs.IoTECS.Protocol");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,42,FOLLOW_40); 

            			newLeafNode(otherlv_5, grammarAccess.getEdgeDeviceAccess().getSpeedKeyword_5());
            		
            // InternalIoTECS.g:1033:3: ( (lv_speed_6_0= ruleSpeed ) )
            // InternalIoTECS.g:1034:4: (lv_speed_6_0= ruleSpeed )
            {
            // InternalIoTECS.g:1034:4: (lv_speed_6_0= ruleSpeed )
            // InternalIoTECS.g:1035:5: lv_speed_6_0= ruleSpeed
            {

            					newCompositeNode(grammarAccess.getEdgeDeviceAccess().getSpeedSpeedParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_41);
            lv_speed_6_0=ruleSpeed();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getEdgeDeviceRule());
            					}
            					set(
            						current,
            						"speed",
            						lv_speed_6_0,
            						"iotecs.IoTECS.Speed");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_7=(Token)match(input,43,FOLLOW_4); 

            			newLeafNode(otherlv_7, grammarAccess.getEdgeDeviceAccess().getCloudKeyword_7());
            		
            // InternalIoTECS.g:1056:3: ( (otherlv_8= RULE_ID ) )
            // InternalIoTECS.g:1057:4: (otherlv_8= RULE_ID )
            {
            // InternalIoTECS.g:1057:4: (otherlv_8= RULE_ID )
            // InternalIoTECS.g:1058:5: otherlv_8= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEdgeDeviceRule());
            					}
            				
            otherlv_8=(Token)match(input,RULE_ID,FOLLOW_29); 

            					newLeafNode(otherlv_8, grammarAccess.getEdgeDeviceAccess().getCloudCloudCrossReference_8_0());
            				

            }


            }

            otherlv_9=(Token)match(input,33,FOLLOW_11); 

            			newLeafNode(otherlv_9, grammarAccess.getEdgeDeviceAccess().getWorkloadKeyword_9());
            		
            // InternalIoTECS.g:1073:3: ( (lv_workload_10_0= RULE_INT ) )
            // InternalIoTECS.g:1074:4: (lv_workload_10_0= RULE_INT )
            {
            // InternalIoTECS.g:1074:4: (lv_workload_10_0= RULE_INT )
            // InternalIoTECS.g:1075:5: lv_workload_10_0= RULE_INT
            {
            lv_workload_10_0=(Token)match(input,RULE_INT,FOLLOW_30); 

            					newLeafNode(lv_workload_10_0, grammarAccess.getEdgeDeviceAccess().getWorkloadINTTerminalRuleCall_10_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEdgeDeviceRule());
            					}
            					setWithLastConsumed(
            						current,
            						"workload",
            						lv_workload_10_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalIoTECS.g:1091:3: ( (lv_workloadUnit_11_0= ruleTimeUnitForWorkload ) )
            // InternalIoTECS.g:1092:4: (lv_workloadUnit_11_0= ruleTimeUnitForWorkload )
            {
            // InternalIoTECS.g:1092:4: (lv_workloadUnit_11_0= ruleTimeUnitForWorkload )
            // InternalIoTECS.g:1093:5: lv_workloadUnit_11_0= ruleTimeUnitForWorkload
            {

            					newCompositeNode(grammarAccess.getEdgeDeviceAccess().getWorkloadUnitTimeUnitForWorkloadEnumRuleCall_11_0());
            				
            pushFollow(FOLLOW_42);
            lv_workloadUnit_11_0=ruleTimeUnitForWorkload();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getEdgeDeviceRule());
            					}
            					set(
            						current,
            						"workloadUnit",
            						lv_workloadUnit_11_0,
            						"iotecs.IoTECS.TimeUnitForWorkload");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_12=(Token)match(input,44,FOLLOW_5); 

            			newLeafNode(otherlv_12, grammarAccess.getEdgeDeviceAccess().getDevicesKeyword_12());
            		
            otherlv_13=(Token)match(input,12,FOLLOW_25); 

            			newLeafNode(otherlv_13, grammarAccess.getEdgeDeviceAccess().getLeftCurlyBracketKeyword_13());
            		
            // InternalIoTECS.g:1118:3: ( (lv_devices_14_0= ruleDevices ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==RULE_ID) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalIoTECS.g:1119:4: (lv_devices_14_0= ruleDevices )
            	    {
            	    // InternalIoTECS.g:1119:4: (lv_devices_14_0= ruleDevices )
            	    // InternalIoTECS.g:1120:5: lv_devices_14_0= ruleDevices
            	    {

            	    					newCompositeNode(grammarAccess.getEdgeDeviceAccess().getDevicesDevicesParserRuleCall_14_0());
            	    				
            	    pushFollow(FOLLOW_25);
            	    lv_devices_14_0=ruleDevices();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getEdgeDeviceRule());
            	    					}
            	    					add(
            	    						current,
            	    						"devices",
            	    						lv_devices_14_0,
            	    						"iotecs.IoTECS.Devices");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            otherlv_15=(Token)match(input,24,FOLLOW_20); 

            			newLeafNode(otherlv_15, grammarAccess.getEdgeDeviceAccess().getRightCurlyBracketKeyword_15());
            		
            otherlv_16=(Token)match(input,24,FOLLOW_2); 

            			newLeafNode(otherlv_16, grammarAccess.getEdgeDeviceAccess().getRightCurlyBracketKeyword_16());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEdgeDevice"


    // $ANTLR start "entryRuleSpeed"
    // InternalIoTECS.g:1149:1: entryRuleSpeed returns [String current=null] : iv_ruleSpeed= ruleSpeed EOF ;
    public final String entryRuleSpeed() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleSpeed = null;


        try {
            // InternalIoTECS.g:1149:45: (iv_ruleSpeed= ruleSpeed EOF )
            // InternalIoTECS.g:1150:2: iv_ruleSpeed= ruleSpeed EOF
            {
             newCompositeNode(grammarAccess.getSpeedRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSpeed=ruleSpeed();

            state._fsp--;

             current =iv_ruleSpeed.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSpeed"


    // $ANTLR start "ruleSpeed"
    // InternalIoTECS.g:1156:1: ruleSpeed returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'Max' | this_INT_1= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleSpeed() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;


        	enterRule();

        try {
            // InternalIoTECS.g:1162:2: ( (kw= 'Max' | this_INT_1= RULE_INT ) )
            // InternalIoTECS.g:1163:2: (kw= 'Max' | this_INT_1= RULE_INT )
            {
            // InternalIoTECS.g:1163:2: (kw= 'Max' | this_INT_1= RULE_INT )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==45) ) {
                alt12=1;
            }
            else if ( (LA12_0==RULE_INT) ) {
                alt12=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // InternalIoTECS.g:1164:3: kw= 'Max'
                    {
                    kw=(Token)match(input,45,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getSpeedAccess().getMaxKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalIoTECS.g:1170:3: this_INT_1= RULE_INT
                    {
                    this_INT_1=(Token)match(input,RULE_INT,FOLLOW_2); 

                    			current.merge(this_INT_1);
                    		

                    			newLeafNode(this_INT_1, grammarAccess.getSpeedAccess().getINTTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSpeed"


    // $ANTLR start "entryRuleEdgeDevices"
    // InternalIoTECS.g:1181:1: entryRuleEdgeDevices returns [EObject current=null] : iv_ruleEdgeDevices= ruleEdgeDevices EOF ;
    public final EObject entryRuleEdgeDevices() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEdgeDevices = null;


        try {
            // InternalIoTECS.g:1181:52: (iv_ruleEdgeDevices= ruleEdgeDevices EOF )
            // InternalIoTECS.g:1182:2: iv_ruleEdgeDevices= ruleEdgeDevices EOF
            {
             newCompositeNode(grammarAccess.getEdgeDevicesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEdgeDevices=ruleEdgeDevices();

            state._fsp--;

             current =iv_ruleEdgeDevices; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEdgeDevices"


    // $ANTLR start "ruleEdgeDevices"
    // InternalIoTECS.g:1188:1: ruleEdgeDevices returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )? ) ;
    public final EObject ruleEdgeDevices() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_n_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalIoTECS.g:1194:2: ( ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )? ) )
            // InternalIoTECS.g:1195:2: ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )? )
            {
            // InternalIoTECS.g:1195:2: ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )? )
            // InternalIoTECS.g:1196:3: ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )?
            {
            // InternalIoTECS.g:1196:3: ( (otherlv_0= RULE_ID ) )
            // InternalIoTECS.g:1197:4: (otherlv_0= RULE_ID )
            {
            // InternalIoTECS.g:1197:4: (otherlv_0= RULE_ID )
            // InternalIoTECS.g:1198:5: otherlv_0= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEdgeDevicesRule());
            					}
            				
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_34); 

            					newLeafNode(otherlv_0, grammarAccess.getEdgeDevicesAccess().getSaEdgeDeviceCrossReference_0_0());
            				

            }


            }

            otherlv_1=(Token)match(input,37,FOLLOW_11); 

            			newLeafNode(otherlv_1, grammarAccess.getEdgeDevicesAccess().getLeftSquareBracketKeyword_1());
            		
            // InternalIoTECS.g:1213:3: ( (lv_n_2_0= RULE_INT ) )
            // InternalIoTECS.g:1214:4: (lv_n_2_0= RULE_INT )
            {
            // InternalIoTECS.g:1214:4: (lv_n_2_0= RULE_INT )
            // InternalIoTECS.g:1215:5: lv_n_2_0= RULE_INT
            {
            lv_n_2_0=(Token)match(input,RULE_INT,FOLLOW_35); 

            					newLeafNode(lv_n_2_0, grammarAccess.getEdgeDevicesAccess().getNINTTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEdgeDevicesRule());
            					}
            					setWithLastConsumed(
            						current,
            						"n",
            						lv_n_2_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_3=(Token)match(input,38,FOLLOW_36); 

            			newLeafNode(otherlv_3, grammarAccess.getEdgeDevicesAccess().getRightSquareBracketKeyword_3());
            		
            // InternalIoTECS.g:1235:3: (otherlv_4= ',' )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==39) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalIoTECS.g:1236:4: otherlv_4= ','
                    {
                    otherlv_4=(Token)match(input,39,FOLLOW_2); 

                    				newLeafNode(otherlv_4, grammarAccess.getEdgeDevicesAccess().getCommaKeyword_4());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEdgeDevices"


    // $ANTLR start "entryRuleDevices"
    // InternalIoTECS.g:1245:1: entryRuleDevices returns [EObject current=null] : iv_ruleDevices= ruleDevices EOF ;
    public final EObject entryRuleDevices() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDevices = null;


        try {
            // InternalIoTECS.g:1245:48: (iv_ruleDevices= ruleDevices EOF )
            // InternalIoTECS.g:1246:2: iv_ruleDevices= ruleDevices EOF
            {
             newCompositeNode(grammarAccess.getDevicesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDevices=ruleDevices();

            state._fsp--;

             current =iv_ruleDevices; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDevices"


    // $ANTLR start "ruleDevices"
    // InternalIoTECS.g:1252:1: ruleDevices returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )? ) ;
    public final EObject ruleDevices() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_n_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalIoTECS.g:1258:2: ( ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )? ) )
            // InternalIoTECS.g:1259:2: ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )? )
            {
            // InternalIoTECS.g:1259:2: ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )? )
            // InternalIoTECS.g:1260:3: ( (otherlv_0= RULE_ID ) ) otherlv_1= '[' ( (lv_n_2_0= RULE_INT ) ) otherlv_3= ']' (otherlv_4= ',' )?
            {
            // InternalIoTECS.g:1260:3: ( (otherlv_0= RULE_ID ) )
            // InternalIoTECS.g:1261:4: (otherlv_0= RULE_ID )
            {
            // InternalIoTECS.g:1261:4: (otherlv_0= RULE_ID )
            // InternalIoTECS.g:1262:5: otherlv_0= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDevicesRule());
            					}
            				
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_34); 

            					newLeafNode(otherlv_0, grammarAccess.getDevicesAccess().getADeviceCrossReference_0_0());
            				

            }


            }

            otherlv_1=(Token)match(input,37,FOLLOW_11); 

            			newLeafNode(otherlv_1, grammarAccess.getDevicesAccess().getLeftSquareBracketKeyword_1());
            		
            // InternalIoTECS.g:1277:3: ( (lv_n_2_0= RULE_INT ) )
            // InternalIoTECS.g:1278:4: (lv_n_2_0= RULE_INT )
            {
            // InternalIoTECS.g:1278:4: (lv_n_2_0= RULE_INT )
            // InternalIoTECS.g:1279:5: lv_n_2_0= RULE_INT
            {
            lv_n_2_0=(Token)match(input,RULE_INT,FOLLOW_35); 

            					newLeafNode(lv_n_2_0, grammarAccess.getDevicesAccess().getNINTTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDevicesRule());
            					}
            					setWithLastConsumed(
            						current,
            						"n",
            						lv_n_2_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_3=(Token)match(input,38,FOLLOW_36); 

            			newLeafNode(otherlv_3, grammarAccess.getDevicesAccess().getRightSquareBracketKeyword_3());
            		
            // InternalIoTECS.g:1299:3: (otherlv_4= ',' )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==39) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalIoTECS.g:1300:4: otherlv_4= ','
                    {
                    otherlv_4=(Token)match(input,39,FOLLOW_2); 

                    				newLeafNode(otherlv_4, grammarAccess.getDevicesAccess().getCommaKeyword_4());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDevices"


    // $ANTLR start "entryRuleDevice"
    // InternalIoTECS.g:1309:1: entryRuleDevice returns [EObject current=null] : iv_ruleDevice= ruleDevice EOF ;
    public final EObject entryRuleDevice() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDevice = null;


        try {
            // InternalIoTECS.g:1309:47: (iv_ruleDevice= ruleDevice EOF )
            // InternalIoTECS.g:1310:2: iv_ruleDevice= ruleDevice EOF
            {
             newCompositeNode(grammarAccess.getDeviceRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDevice=ruleDevice();

            state._fsp--;

             current =iv_ruleDevice; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDevice"


    // $ANTLR start "ruleDevice"
    // InternalIoTECS.g:1316:1: ruleDevice returns [EObject current=null] : (otherlv_0= 'Device:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'period:' ( (lv_period_4_0= RULE_INT ) ) otherlv_5= 'payload:' ( (lv_payload_6_0= RULE_INT ) ) ( (lv_payloadUnit_7_0= rulePayloadUnit ) ) otherlv_8= '}' ) ;
    public final EObject ruleDevice() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_period_4_0=null;
        Token otherlv_5=null;
        Token lv_payload_6_0=null;
        Token otherlv_8=null;
        Enumerator lv_payloadUnit_7_0 = null;



        	enterRule();

        try {
            // InternalIoTECS.g:1322:2: ( (otherlv_0= 'Device:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'period:' ( (lv_period_4_0= RULE_INT ) ) otherlv_5= 'payload:' ( (lv_payload_6_0= RULE_INT ) ) ( (lv_payloadUnit_7_0= rulePayloadUnit ) ) otherlv_8= '}' ) )
            // InternalIoTECS.g:1323:2: (otherlv_0= 'Device:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'period:' ( (lv_period_4_0= RULE_INT ) ) otherlv_5= 'payload:' ( (lv_payload_6_0= RULE_INT ) ) ( (lv_payloadUnit_7_0= rulePayloadUnit ) ) otherlv_8= '}' )
            {
            // InternalIoTECS.g:1323:2: (otherlv_0= 'Device:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'period:' ( (lv_period_4_0= RULE_INT ) ) otherlv_5= 'payload:' ( (lv_payload_6_0= RULE_INT ) ) ( (lv_payloadUnit_7_0= rulePayloadUnit ) ) otherlv_8= '}' )
            // InternalIoTECS.g:1324:3: otherlv_0= 'Device:' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'period:' ( (lv_period_4_0= RULE_INT ) ) otherlv_5= 'payload:' ( (lv_payload_6_0= RULE_INT ) ) ( (lv_payloadUnit_7_0= rulePayloadUnit ) ) otherlv_8= '}'
            {
            otherlv_0=(Token)match(input,46,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getDeviceAccess().getDeviceKeyword_0());
            		
            // InternalIoTECS.g:1328:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalIoTECS.g:1329:4: (lv_name_1_0= RULE_ID )
            {
            // InternalIoTECS.g:1329:4: (lv_name_1_0= RULE_ID )
            // InternalIoTECS.g:1330:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getDeviceAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviceRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_43); 

            			newLeafNode(otherlv_2, grammarAccess.getDeviceAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,47,FOLLOW_11); 

            			newLeafNode(otherlv_3, grammarAccess.getDeviceAccess().getPeriodKeyword_3());
            		
            // InternalIoTECS.g:1354:3: ( (lv_period_4_0= RULE_INT ) )
            // InternalIoTECS.g:1355:4: (lv_period_4_0= RULE_INT )
            {
            // InternalIoTECS.g:1355:4: (lv_period_4_0= RULE_INT )
            // InternalIoTECS.g:1356:5: lv_period_4_0= RULE_INT
            {
            lv_period_4_0=(Token)match(input,RULE_INT,FOLLOW_44); 

            					newLeafNode(lv_period_4_0, grammarAccess.getDeviceAccess().getPeriodINTTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviceRule());
            					}
            					setWithLastConsumed(
            						current,
            						"period",
            						lv_period_4_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_5=(Token)match(input,48,FOLLOW_11); 

            			newLeafNode(otherlv_5, grammarAccess.getDeviceAccess().getPayloadKeyword_5());
            		
            // InternalIoTECS.g:1376:3: ( (lv_payload_6_0= RULE_INT ) )
            // InternalIoTECS.g:1377:4: (lv_payload_6_0= RULE_INT )
            {
            // InternalIoTECS.g:1377:4: (lv_payload_6_0= RULE_INT )
            // InternalIoTECS.g:1378:5: lv_payload_6_0= RULE_INT
            {
            lv_payload_6_0=(Token)match(input,RULE_INT,FOLLOW_45); 

            					newLeafNode(lv_payload_6_0, grammarAccess.getDeviceAccess().getPayloadINTTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviceRule());
            					}
            					setWithLastConsumed(
            						current,
            						"payload",
            						lv_payload_6_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalIoTECS.g:1394:3: ( (lv_payloadUnit_7_0= rulePayloadUnit ) )
            // InternalIoTECS.g:1395:4: (lv_payloadUnit_7_0= rulePayloadUnit )
            {
            // InternalIoTECS.g:1395:4: (lv_payloadUnit_7_0= rulePayloadUnit )
            // InternalIoTECS.g:1396:5: lv_payloadUnit_7_0= rulePayloadUnit
            {

            					newCompositeNode(grammarAccess.getDeviceAccess().getPayloadUnitPayloadUnitEnumRuleCall_7_0());
            				
            pushFollow(FOLLOW_20);
            lv_payloadUnit_7_0=rulePayloadUnit();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDeviceRule());
            					}
            					set(
            						current,
            						"payloadUnit",
            						lv_payloadUnit_7_0,
            						"iotecs.IoTECS.PayloadUnit");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_8=(Token)match(input,24,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getDeviceAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDevice"


    // $ANTLR start "entryRuleIP"
    // InternalIoTECS.g:1421:1: entryRuleIP returns [String current=null] : iv_ruleIP= ruleIP EOF ;
    public final String entryRuleIP() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleIP = null;


        try {
            // InternalIoTECS.g:1421:42: (iv_ruleIP= ruleIP EOF )
            // InternalIoTECS.g:1422:2: iv_ruleIP= ruleIP EOF
            {
             newCompositeNode(grammarAccess.getIPRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIP=ruleIP();

            state._fsp--;

             current =iv_ruleIP.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIP"


    // $ANTLR start "ruleIP"
    // InternalIoTECS.g:1428:1: ruleIP returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_INT_0= RULE_INT kw= '.' this_INT_2= RULE_INT kw= '.' this_INT_4= RULE_INT kw= '.' this_INT_6= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleIP() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;
        Token kw=null;
        Token this_INT_2=null;
        Token this_INT_4=null;
        Token this_INT_6=null;


        	enterRule();

        try {
            // InternalIoTECS.g:1434:2: ( (this_INT_0= RULE_INT kw= '.' this_INT_2= RULE_INT kw= '.' this_INT_4= RULE_INT kw= '.' this_INT_6= RULE_INT ) )
            // InternalIoTECS.g:1435:2: (this_INT_0= RULE_INT kw= '.' this_INT_2= RULE_INT kw= '.' this_INT_4= RULE_INT kw= '.' this_INT_6= RULE_INT )
            {
            // InternalIoTECS.g:1435:2: (this_INT_0= RULE_INT kw= '.' this_INT_2= RULE_INT kw= '.' this_INT_4= RULE_INT kw= '.' this_INT_6= RULE_INT )
            // InternalIoTECS.g:1436:3: this_INT_0= RULE_INT kw= '.' this_INT_2= RULE_INT kw= '.' this_INT_4= RULE_INT kw= '.' this_INT_6= RULE_INT
            {
            this_INT_0=(Token)match(input,RULE_INT,FOLLOW_46); 

            			current.merge(this_INT_0);
            		

            			newLeafNode(this_INT_0, grammarAccess.getIPAccess().getINTTerminalRuleCall_0());
            		
            kw=(Token)match(input,49,FOLLOW_11); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getIPAccess().getFullStopKeyword_1());
            		
            this_INT_2=(Token)match(input,RULE_INT,FOLLOW_46); 

            			current.merge(this_INT_2);
            		

            			newLeafNode(this_INT_2, grammarAccess.getIPAccess().getINTTerminalRuleCall_2());
            		
            kw=(Token)match(input,49,FOLLOW_11); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getIPAccess().getFullStopKeyword_3());
            		
            this_INT_4=(Token)match(input,RULE_INT,FOLLOW_46); 

            			current.merge(this_INT_4);
            		

            			newLeafNode(this_INT_4, grammarAccess.getIPAccess().getINTTerminalRuleCall_4());
            		
            kw=(Token)match(input,49,FOLLOW_11); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getIPAccess().getFullStopKeyword_5());
            		
            this_INT_6=(Token)match(input,RULE_INT,FOLLOW_2); 

            			current.merge(this_INT_6);
            		

            			newLeafNode(this_INT_6, grammarAccess.getIPAccess().getINTTerminalRuleCall_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIP"


    // $ANTLR start "ruleTimeUnit"
    // InternalIoTECS.g:1483:1: ruleTimeUnit returns [Enumerator current=null] : ( (enumLiteral_0= 'ms' ) | (enumLiteral_1= 's' ) | (enumLiteral_2= 'm' ) | (enumLiteral_3= 'h' ) ) ;
    public final Enumerator ruleTimeUnit() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalIoTECS.g:1489:2: ( ( (enumLiteral_0= 'ms' ) | (enumLiteral_1= 's' ) | (enumLiteral_2= 'm' ) | (enumLiteral_3= 'h' ) ) )
            // InternalIoTECS.g:1490:2: ( (enumLiteral_0= 'ms' ) | (enumLiteral_1= 's' ) | (enumLiteral_2= 'm' ) | (enumLiteral_3= 'h' ) )
            {
            // InternalIoTECS.g:1490:2: ( (enumLiteral_0= 'ms' ) | (enumLiteral_1= 's' ) | (enumLiteral_2= 'm' ) | (enumLiteral_3= 'h' ) )
            int alt15=4;
            switch ( input.LA(1) ) {
            case 50:
                {
                alt15=1;
                }
                break;
            case 51:
                {
                alt15=2;
                }
                break;
            case 52:
                {
                alt15=3;
                }
                break;
            case 53:
                {
                alt15=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }

            switch (alt15) {
                case 1 :
                    // InternalIoTECS.g:1491:3: (enumLiteral_0= 'ms' )
                    {
                    // InternalIoTECS.g:1491:3: (enumLiteral_0= 'ms' )
                    // InternalIoTECS.g:1492:4: enumLiteral_0= 'ms'
                    {
                    enumLiteral_0=(Token)match(input,50,FOLLOW_2); 

                    				current = grammarAccess.getTimeUnitAccess().getMillisecondEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getTimeUnitAccess().getMillisecondEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalIoTECS.g:1499:3: (enumLiteral_1= 's' )
                    {
                    // InternalIoTECS.g:1499:3: (enumLiteral_1= 's' )
                    // InternalIoTECS.g:1500:4: enumLiteral_1= 's'
                    {
                    enumLiteral_1=(Token)match(input,51,FOLLOW_2); 

                    				current = grammarAccess.getTimeUnitAccess().getSecondEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getTimeUnitAccess().getSecondEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalIoTECS.g:1507:3: (enumLiteral_2= 'm' )
                    {
                    // InternalIoTECS.g:1507:3: (enumLiteral_2= 'm' )
                    // InternalIoTECS.g:1508:4: enumLiteral_2= 'm'
                    {
                    enumLiteral_2=(Token)match(input,52,FOLLOW_2); 

                    				current = grammarAccess.getTimeUnitAccess().getMinuteEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getTimeUnitAccess().getMinuteEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalIoTECS.g:1515:3: (enumLiteral_3= 'h' )
                    {
                    // InternalIoTECS.g:1515:3: (enumLiteral_3= 'h' )
                    // InternalIoTECS.g:1516:4: enumLiteral_3= 'h'
                    {
                    enumLiteral_3=(Token)match(input,53,FOLLOW_2); 

                    				current = grammarAccess.getTimeUnitAccess().getHourEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getTimeUnitAccess().getHourEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeUnit"


    // $ANTLR start "ruleTimeUnitForWorkload"
    // InternalIoTECS.g:1526:1: ruleTimeUnitForWorkload returns [Enumerator current=null] : ( (enumLiteral_0= 'ms' ) | (enumLiteral_1= 's' ) | (enumLiteral_2= 'm' ) ) ;
    public final Enumerator ruleTimeUnitForWorkload() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalIoTECS.g:1532:2: ( ( (enumLiteral_0= 'ms' ) | (enumLiteral_1= 's' ) | (enumLiteral_2= 'm' ) ) )
            // InternalIoTECS.g:1533:2: ( (enumLiteral_0= 'ms' ) | (enumLiteral_1= 's' ) | (enumLiteral_2= 'm' ) )
            {
            // InternalIoTECS.g:1533:2: ( (enumLiteral_0= 'ms' ) | (enumLiteral_1= 's' ) | (enumLiteral_2= 'm' ) )
            int alt16=3;
            switch ( input.LA(1) ) {
            case 50:
                {
                alt16=1;
                }
                break;
            case 51:
                {
                alt16=2;
                }
                break;
            case 52:
                {
                alt16=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }

            switch (alt16) {
                case 1 :
                    // InternalIoTECS.g:1534:3: (enumLiteral_0= 'ms' )
                    {
                    // InternalIoTECS.g:1534:3: (enumLiteral_0= 'ms' )
                    // InternalIoTECS.g:1535:4: enumLiteral_0= 'ms'
                    {
                    enumLiteral_0=(Token)match(input,50,FOLLOW_2); 

                    				current = grammarAccess.getTimeUnitForWorkloadAccess().getMillisecondEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getTimeUnitForWorkloadAccess().getMillisecondEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalIoTECS.g:1542:3: (enumLiteral_1= 's' )
                    {
                    // InternalIoTECS.g:1542:3: (enumLiteral_1= 's' )
                    // InternalIoTECS.g:1543:4: enumLiteral_1= 's'
                    {
                    enumLiteral_1=(Token)match(input,51,FOLLOW_2); 

                    				current = grammarAccess.getTimeUnitForWorkloadAccess().getSecondEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getTimeUnitForWorkloadAccess().getSecondEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalIoTECS.g:1550:3: (enumLiteral_2= 'm' )
                    {
                    // InternalIoTECS.g:1550:3: (enumLiteral_2= 'm' )
                    // InternalIoTECS.g:1551:4: enumLiteral_2= 'm'
                    {
                    enumLiteral_2=(Token)match(input,52,FOLLOW_2); 

                    				current = grammarAccess.getTimeUnitForWorkloadAccess().getMinuteEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getTimeUnitForWorkloadAccess().getMinuteEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeUnitForWorkload"


    // $ANTLR start "rulePayloadUnit"
    // InternalIoTECS.g:1561:1: rulePayloadUnit returns [Enumerator current=null] : ( (enumLiteral_0= 'b' ) | (enumLiteral_1= 'Mb' ) | (enumLiteral_2= 'Kb' ) ) ;
    public final Enumerator rulePayloadUnit() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalIoTECS.g:1567:2: ( ( (enumLiteral_0= 'b' ) | (enumLiteral_1= 'Mb' ) | (enumLiteral_2= 'Kb' ) ) )
            // InternalIoTECS.g:1568:2: ( (enumLiteral_0= 'b' ) | (enumLiteral_1= 'Mb' ) | (enumLiteral_2= 'Kb' ) )
            {
            // InternalIoTECS.g:1568:2: ( (enumLiteral_0= 'b' ) | (enumLiteral_1= 'Mb' ) | (enumLiteral_2= 'Kb' ) )
            int alt17=3;
            switch ( input.LA(1) ) {
            case 54:
                {
                alt17=1;
                }
                break;
            case 55:
                {
                alt17=2;
                }
                break;
            case 56:
                {
                alt17=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // InternalIoTECS.g:1569:3: (enumLiteral_0= 'b' )
                    {
                    // InternalIoTECS.g:1569:3: (enumLiteral_0= 'b' )
                    // InternalIoTECS.g:1570:4: enumLiteral_0= 'b'
                    {
                    enumLiteral_0=(Token)match(input,54,FOLLOW_2); 

                    				current = grammarAccess.getPayloadUnitAccess().getByteEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getPayloadUnitAccess().getByteEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalIoTECS.g:1577:3: (enumLiteral_1= 'Mb' )
                    {
                    // InternalIoTECS.g:1577:3: (enumLiteral_1= 'Mb' )
                    // InternalIoTECS.g:1578:4: enumLiteral_1= 'Mb'
                    {
                    enumLiteral_1=(Token)match(input,55,FOLLOW_2); 

                    				current = grammarAccess.getPayloadUnitAccess().getMbEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getPayloadUnitAccess().getMbEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalIoTECS.g:1585:3: (enumLiteral_2= 'Kb' )
                    {
                    // InternalIoTECS.g:1585:3: (enumLiteral_2= 'Kb' )
                    // InternalIoTECS.g:1586:4: enumLiteral_2= 'Kb'
                    {
                    enumLiteral_2=(Token)match(input,56,FOLLOW_2); 

                    				current = grammarAccess.getPayloadUnitAccess().getKbEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getPayloadUnitAccess().getKbEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePayloadUnit"


    // $ANTLR start "ruleProtocol"
    // InternalIoTECS.g:1596:1: ruleProtocol returns [Enumerator current=null] : ( (enumLiteral_0= 'UDP' ) | (enumLiteral_1= 'TCP' ) ) ;
    public final Enumerator ruleProtocol() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalIoTECS.g:1602:2: ( ( (enumLiteral_0= 'UDP' ) | (enumLiteral_1= 'TCP' ) ) )
            // InternalIoTECS.g:1603:2: ( (enumLiteral_0= 'UDP' ) | (enumLiteral_1= 'TCP' ) )
            {
            // InternalIoTECS.g:1603:2: ( (enumLiteral_0= 'UDP' ) | (enumLiteral_1= 'TCP' ) )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==57) ) {
                alt18=1;
            }
            else if ( (LA18_0==58) ) {
                alt18=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // InternalIoTECS.g:1604:3: (enumLiteral_0= 'UDP' )
                    {
                    // InternalIoTECS.g:1604:3: (enumLiteral_0= 'UDP' )
                    // InternalIoTECS.g:1605:4: enumLiteral_0= 'UDP'
                    {
                    enumLiteral_0=(Token)match(input,57,FOLLOW_2); 

                    				current = grammarAccess.getProtocolAccess().getUdpEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getProtocolAccess().getUdpEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalIoTECS.g:1612:3: (enumLiteral_1= 'TCP' )
                    {
                    // InternalIoTECS.g:1612:3: (enumLiteral_1= 'TCP' )
                    // InternalIoTECS.g:1613:4: enumLiteral_1= 'TCP'
                    {
                    enumLiteral_1=(Token)match(input,58,FOLLOW_2); 

                    				current = grammarAccess.getProtocolAccess().getTcpEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getProtocolAccess().getTcpEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProtocol"


    // $ANTLR start "rulePlatformType"
    // InternalIoTECS.g:1623:1: rulePlatformType returns [Enumerator current=null] : ( (enumLiteral_0= 'Docker' ) | (enumLiteral_1= 'VM' ) | (enumLiteral_2= 'Native' ) ) ;
    public final Enumerator rulePlatformType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalIoTECS.g:1629:2: ( ( (enumLiteral_0= 'Docker' ) | (enumLiteral_1= 'VM' ) | (enumLiteral_2= 'Native' ) ) )
            // InternalIoTECS.g:1630:2: ( (enumLiteral_0= 'Docker' ) | (enumLiteral_1= 'VM' ) | (enumLiteral_2= 'Native' ) )
            {
            // InternalIoTECS.g:1630:2: ( (enumLiteral_0= 'Docker' ) | (enumLiteral_1= 'VM' ) | (enumLiteral_2= 'Native' ) )
            int alt19=3;
            switch ( input.LA(1) ) {
            case 59:
                {
                alt19=1;
                }
                break;
            case 60:
                {
                alt19=2;
                }
                break;
            case 61:
                {
                alt19=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }

            switch (alt19) {
                case 1 :
                    // InternalIoTECS.g:1631:3: (enumLiteral_0= 'Docker' )
                    {
                    // InternalIoTECS.g:1631:3: (enumLiteral_0= 'Docker' )
                    // InternalIoTECS.g:1632:4: enumLiteral_0= 'Docker'
                    {
                    enumLiteral_0=(Token)match(input,59,FOLLOW_2); 

                    				current = grammarAccess.getPlatformTypeAccess().getDockerEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getPlatformTypeAccess().getDockerEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalIoTECS.g:1639:3: (enumLiteral_1= 'VM' )
                    {
                    // InternalIoTECS.g:1639:3: (enumLiteral_1= 'VM' )
                    // InternalIoTECS.g:1640:4: enumLiteral_1= 'VM'
                    {
                    enumLiteral_1=(Token)match(input,60,FOLLOW_2); 

                    				current = grammarAccess.getPlatformTypeAccess().getVmEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getPlatformTypeAccess().getVmEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalIoTECS.g:1647:3: (enumLiteral_2= 'Native' )
                    {
                    // InternalIoTECS.g:1647:3: (enumLiteral_2= 'Native' )
                    // InternalIoTECS.g:1648:4: enumLiteral_2= 'Native'
                    {
                    enumLiteral_2=(Token)match(input,61,FOLLOW_2); 

                    				current = grammarAccess.getPlatformTypeAccess().getNativeEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getPlatformTypeAccess().getNativeEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePlatformType"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000410422000802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x3800000000000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000001248000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000001240000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000001200000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x003C000000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000001000010L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000101004000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x001C000000000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000001004000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000008000000002L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0600000000000000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000200000000040L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x01C0000000000000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0002000000000000L});

}